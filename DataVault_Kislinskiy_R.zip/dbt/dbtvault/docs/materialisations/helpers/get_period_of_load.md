{% docs macro__get_period_of_load %}

A helper macro to fetch the date of the current load cycle. 

{% enddocs %}


{% docs arg__get_period_of_load__start_timestamp %}

The `start_timestamp` of the load, derived from the `start_date`.

{% enddocs %}