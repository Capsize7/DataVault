{{
    config(
        schema='marts',
        materialized='incremental',
    )
}}

select  payment_id, c.first_name || ' ' || c.last_name as customer,
       s.first_name || ' ' || s.last_name as staff,
       title,
       amount,
       rental_date,
       address as customer_address,
       city as customer_city,
       country as customer_country,
       payment_date
from payment
join customer c on payment.customer_id = c.customer_id
join staff s on payment.staff_id = s.staff_id
join rental r on payment.rental_id = r.rental_id
join store st on c.store_id = st.store_id
join address ad on c.address_id = ad.address_id
join city ct on ad.city_id = ct.city_id
join country cn on ct.country_id = cn.country_id
join inventory inv on r.inventory_id = inv.inventory_id
join film f on inv.film_id = f.film_id
where '{{ var("start_date") }}' <= payment_date
and payment_date < '{{ var("end_date") }}'
order by payment_id
