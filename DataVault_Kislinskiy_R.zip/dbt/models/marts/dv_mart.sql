{{
    config(
        schema='marts',
        materialized='incremental',
    )
}}

select lpcsr.hash_payment_id, sc.first_name || ' ' || sc.last_name as customer,
       st.first_name || ' ' || st.last_name as staff,
       title,
       amount,
       rental_date,
       address,
       city as customer_city,
       country as customer_country,
       lpcsr.payment_date
    from {{ source('dv', 'l_payment_customer_staff_rental') }} as lpcsr
join {{ source('dv', 's_payment') }} sp on lpcsr.hash_payment_id = sp.hash_payment_id
join {{ source('dv', 's_customer') }} sc on lpcsr.hash_customer_id = sc.hash_customer_id
join {{ source('dv', 's_staff') }} st on lpcsr.hash_staff_id = st.hash_staff_id
join {{ source('dv', 's_rental') }} sr on lpcsr.hash_rental_id = sr.hash_rental_id
join {{ source('dv', 'l_customer_address') }} lc on sc.hash_customer_id = lc.hash_customer_id
join {{ source('dv', 'h_address') }} ha on lc.hash_address = ha.hash_address
join {{ source('dv', 'l_address_city') }} la on ha.hash_address = la.hash_address
join {{ source('dv', 'h_city') }} hc on la.hash_city = hc.hash_city
join {{ source('dv', 'l_city_country') }} lcc on hc.hash_city = lcc.hash_city
join {{ source('dv', 'h_country') }} hcc on lcc.hash_country = hcc.hash_country
join {{ source('dv', 'l_rental_inventory_customer_staff') }} lrics on lpcsr.hash_rental_id = lrics.hash_rental_id
join {{ source('dv', 'l_inventory_store_film') }} lisf on lrics.hash_inventory_id = lisf.hash_inventory_id
join {{ source('dv', 'h_film') }} on lisf.hash_film_title = h_film.hash_film_title
where '{{ var("start_date") }}' <= lpcsr.payment_date
and lpcsr.payment_date < '{{ var("end_date") }}'

