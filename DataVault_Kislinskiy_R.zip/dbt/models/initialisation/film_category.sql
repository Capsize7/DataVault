select name, title, film_category.last_update from film_category
join film using (film_id)
join category using (category_id)
where
'{{ var("start_date") }}' <= film_category.last_update
and
film_category.last_update < '{{ var("end_date") }}'
