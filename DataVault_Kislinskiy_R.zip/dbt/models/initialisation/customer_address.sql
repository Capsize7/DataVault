select customer_id, address, customer.last_update from customer
join address using (address_id)
where
'{{ var("start_date") }}' <= customer.last_update
and
customer.last_update < '{{ var("end_date") }}'
