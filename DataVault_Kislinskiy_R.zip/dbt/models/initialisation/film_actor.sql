select actor_id, title, film_actor.last_update from film_actor
join film using (film_id)
where
'{{ var("start_date") }}' <= film_actor.last_update
and
film_actor.last_update < '{{ var("end_date") }}'
