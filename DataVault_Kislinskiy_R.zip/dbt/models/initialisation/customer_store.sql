select store.store_id, customer_id, store.last_update from customer
join store using (store_id)
where
'{{ var("start_date") }}' <= store.last_update
and
store.last_update < '{{ var("end_date") }}'
