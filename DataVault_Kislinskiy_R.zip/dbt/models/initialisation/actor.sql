select * from actor
where
'{{ var("start_date") }}' <= last_update
and
last_update < '{{ var("end_date") }}'
