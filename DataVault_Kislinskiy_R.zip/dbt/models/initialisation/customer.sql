select * from customer
where
'{{ var("start_date") }}' <= last_update
and
last_update < '{{ var("end_date") }}'
