select address, city, address.last_update from address
join city using (city_id)
where
'{{ var("start_date") }}' <= address.last_update
and
address.last_update < '{{ var("end_date") }}'
