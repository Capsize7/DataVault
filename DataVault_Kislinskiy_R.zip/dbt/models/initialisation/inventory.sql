select inventory_id, title, store_id, inventory.last_update from inventory
join film using (film_id)
where
'{{ var("start_date") }}' <= inventory.last_update
and
inventory.last_update < '{{ var("end_date") }}'
