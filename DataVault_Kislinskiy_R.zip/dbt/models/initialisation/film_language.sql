select name, title, film.last_update from film
join language using (language_id)
where
'{{ var("start_date") }}' <= film.last_update
and
film.last_update < '{{ var("end_date") }}'
