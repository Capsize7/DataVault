select store_id, address, store.last_update from store
join address using (address_id)
where
'{{ var("start_date") }}' <= store.last_update
and
store.last_update < '{{ var("end_date") }}'
