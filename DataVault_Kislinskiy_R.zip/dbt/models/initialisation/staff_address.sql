select staff_id, address, staff.last_update from staff
join address using (address_id)
where
'{{ var("start_date") }}' <= staff.last_update
and
staff.last_update < '{{ var("end_date") }}'
