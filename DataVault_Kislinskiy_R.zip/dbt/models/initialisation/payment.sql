select * from payment
where
'{{ var("start_date") }}' <= payment_date
and
payment_date < '{{ var("end_date") }}'
