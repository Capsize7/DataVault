select city, country, city.last_update from city
join country using (country_id)
where
'{{ var("start_date") }}' <= city.last_update
and
city.last_update < '{{ var("end_date") }}'
