{{
    config(
        schema='dv',
        materialized='incremental')
}}


{%- set source_model = "stg_language" -%}
{%- set src_pk = "hash_language_name" -%}
{%- set src_nk = "name" -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}


{{ dbtvault.hub(src_pk=src_pk, src_nk=src_nk, src_ldts=src_ldts,
                src_source=src_source, source_model=source_model) }}
