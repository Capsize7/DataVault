{{
    config(
        schema='dv',
        materialized='incremental')
}}

{%- set source_model = "stg_customer_store" -%}
{%- set src_pk = "link_customer_store" -%}
{%- set src_fk = ["hash_customer_id", "hash_store_id"] -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}

{{ dbtvault.link(src_pk=src_pk, src_fk=src_fk, src_ldts=src_ldts,
                 src_source=src_source, source_model=source_model)}}
