{{
    config(
        schema='dv',
        materialized='incremental'
    )
}}


{%- set source_model = "stg_film" -%}
{%- set src_pk = "hash_film_title" -%}
{%- set src_hashdiff = "film_hashdiff" -%}
{%- set src_payload = ["title", "description", "release_year", "rental_duration", "rental_rate",
    "length", "replacement_cost", "rating", "special_features", "fulltext"] -%}
{%- set src_eff = "effective_from" -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}


{{ dbtvault.sat(src_pk=src_pk, src_hashdiff=src_hashdiff,
                src_payload=src_payload, src_eff=src_eff,
                src_ldts=src_ldts, src_source=src_source,
                source_model=source_model) }}
