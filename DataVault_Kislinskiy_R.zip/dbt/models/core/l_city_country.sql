{{
    config(
        schema='dv',
        materialized='incremental')
}}

{%- set source_model = "stg_city_country" -%}
{%- set src_pk = "link_country_city" -%}
{%- set src_fk = ["hash_city", "hash_country"] -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}

{{ dbtvault.link(src_pk=src_pk, src_fk=src_fk, src_ldts=src_ldts,
                 src_source=src_source, source_model=source_model)}}
