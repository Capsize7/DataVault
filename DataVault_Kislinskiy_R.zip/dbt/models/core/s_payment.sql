{{
    config(
        schema='dv',
        materialized='incremental'
    )
}}


{%- set source_model = "stg_payment" -%}
{%- set src_pk = "hash_payment_id" -%}
{%- set src_hashdiff = "payment_hashdiff" -%}
{%- set src_payload = ["amount"] -%}
{%- set src_eff = "effective_from" -%}
{%- set src_ldts = "payment_date" -%}
{%- set src_source = "record_source" -%}


{{ dbtvault.sat(src_pk=src_pk, src_hashdiff=src_hashdiff,
                src_payload=src_payload, src_eff=src_eff,
                src_ldts=src_ldts, src_source=src_source,
                source_model=source_model) }}
