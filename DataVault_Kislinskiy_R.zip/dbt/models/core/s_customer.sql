{{
    config(
        schema='dv',
        materialized='incremental'
    )
}}


{%- set source_model = "stg_customer" -%}
{%- set src_pk = "hash_customer_id" -%}
{%- set src_hashdiff = "customer_hashdiff" -%}
{%- set src_payload = ["first_name", "last_name", "email", "activebool", "create_date", "active"] -%}
{%- set src_eff = "effective_from" -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}


{{ dbtvault.sat(src_pk=src_pk, src_hashdiff=src_hashdiff,
                src_payload=src_payload, src_eff=src_eff,
                src_ldts=src_ldts, src_source=src_source,
                source_model=source_model) }}
