{{
    config(
        schema='dv',
        materialized='incremental')
}}

{%- set source_model = "stg_rental" -%}
{%- set src_pk = "link_rental_inventory_customer_staff" -%}
{%- set src_fk = ["hash_rental_id", "hash_customer_id", "hash_staff_id", "hash_inventory_id"] -%}
{%- set src_ldts = "last_update" -%}
{%- set src_source = "record_source" -%}

{{ dbtvault.link(src_pk=src_pk, src_fk=src_fk, src_ldts=src_ldts,
                 src_source=src_source, source_model=source_model)}}
