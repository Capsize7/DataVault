{{
    config(
        schema='dv',
        materialized='incremental')
}}

{%- set source_model = "stg_payment" -%}
{%- set src_pk = "link_payment_customer_staff_rental" -%}
{%- set src_fk = ["hash_payment_id", "hash_customer_id", "hash_staff_id", "hash_rental_id"] -%}
{%- set src_ldts = "payment_date" -%}
{%- set src_source = "record_source" -%}

{{ dbtvault.link(src_pk=src_pk, src_fk=src_fk, src_ldts=src_ldts,
                 src_source=src_source, source_model=source_model)}}
