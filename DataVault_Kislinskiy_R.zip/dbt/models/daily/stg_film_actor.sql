{{
    config(
        schema='stage',
        materialized='table',
    )
}}


{%- set yaml_metadata -%}
source_model: 'film_actor'
derived_columns:
  RECORD_SOURCE: '!pagila'
  effective_from: 'now()'
hashed_columns:
  hash_film_title:
    - 'title'
  hash_actor_id:
    - 'actor_id'
  link_film_actor:
    - 'title'
    - 'actor_id'
{%- endset -%}

{% set metadata_dict = fromyaml(yaml_metadata) %}

{% set source_model = metadata_dict['source_model'] %}

{% set derived_columns = metadata_dict['derived_columns'] %}

{% set hashed_columns = metadata_dict['hashed_columns'] %}

{{ dbtvault.stage(include_source_columns=true,
                  source_model=source_model,
                  derived_columns=derived_columns,
                  hashed_columns=hashed_columns,
                  ranked_columns=none) }}
