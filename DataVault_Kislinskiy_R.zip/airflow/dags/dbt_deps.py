from airflow import DAG, macros
from airflow.operators.bash_operator import BashOperator
from airflow.operators.postgres_operator import PostgresOperator
from airflow.utils.dates import days_ago
from datetime import datetime

# [START default_args]
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2019, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}
# [END default_args]

# [START instantiate_dag]
dbt_deps = DAG(
    'dbt_deps',
    default_args=default_args,
    schedule_interval = None,
)

bsh_cmd = 'cd /dbt && dbt deps'
t  = BashOperator(
            task_id='dbt_deps',
            bash_command=bsh_cmd,
            dag=dbt_deps,
)

t
                     
