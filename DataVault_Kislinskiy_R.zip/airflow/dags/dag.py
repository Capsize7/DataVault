from airflow import DAG, macros
from airflow.operators.bash_operator import BashOperator
from airflow.utils.dates import days_ago
from datetime import datetime
import os

# Parse nodes
import json
JSON_MANIFEST_DBT = '/dbt/target/manifest.json'
PARENT_MAP = 'parent_map'

def sanitise_node_names(value):
        segments = value.split('.')
        if (segments[0] == 'model'):
                return value.split('.')[-1]

def get_node_structure():
    with open(JSON_MANIFEST_DBT) as json_data:
        data = json.load(json_data)
    ancestors_data = data[PARENT_MAP]
    tree = {}
    for node in ancestors_data:
            ancestors = list(set(ancestors_data[node]))
            ancestors_2 = []
            for ancestor in ancestors:
                if (sanitise_node_names(ancestor) is not None):
                    ancestors_2.append(sanitise_node_names(ancestor))
                    
            clean_node_name = sanitise_node_names(node)
            if (clean_node_name is not None) and (ancestors_2 is not None):
                    tree[clean_node_name] = {}
                    tree[clean_node_name]['ancestors'] = ancestors_2
                    tree[clean_node_name]['tags'] = data['nodes'][node]['tags']
    
    return tree


# [START default_args]
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 2, 15),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}
# [END default_args]

# [START instantiate_dag]

