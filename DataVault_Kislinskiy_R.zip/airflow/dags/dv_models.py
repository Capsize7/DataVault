from airflow import DAG, macros
from airflow.operators.bash_operator import BashOperator
from airflow.utils.dates import days_ago
from datetime import datetime
import os

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 2, 15),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

dag = DAG(
    'dv_models',
    default_args=default_args,
    description='Managing dbt data pipeline',
    schedule_interval = None,
)
files = os.listdir('../../dbt/models/core/')
date_end = "{{ tomorrow_ds }}"
date_start = "{{ ds }}"
tasks = []
for file in files:
    bsh_cmd = 'cd /dbt && dbt run --models {nodeName} --vars \'{{"start_date":"{start_date}", "end_date":"{end_date}"}}\' '.format(
        nodeName=file.split('.')[0], start_date=date_start, end_date=date_end)
    t = BashOperator(
        task_id=file,
        bash_command=bsh_cmd,
        dag=dag,
        depends_on_past= True)
    tasks.append(t)

ln = len(tasks)//4
tasks[:ln]
tasks[ln:2*ln]
tasks[2*ln:3*ln]
tasks[3*ln:]
